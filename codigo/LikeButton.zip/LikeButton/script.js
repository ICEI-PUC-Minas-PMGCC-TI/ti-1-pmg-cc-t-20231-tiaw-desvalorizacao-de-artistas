localStorage.clear();

// Carrega o valor atual do contador do arquivo JSON
function loadCounter() {
  fetch('data.json')
    .then(response => response.json())
    .then(data => {
      document.getElementById('fav').textContent = data.counter;
      updateCounterLocalStorage(data.counter);
    })
    .catch(error => {
      console.log('Erro ao carregar contador:', error);
    });
}

// Atualiza o valor do contador no armazenamento local
function updateCounterLocalStorage(value) {
  var jsonData = {
    counter: value
  };
  var jsonString = JSON.stringify(jsonData);
  localStorage.setItem('counterData', jsonString);
}

// Função para atualizar o contador (lógica personalizada)
function updateCounter(value) {
  // Lógica para atualizar o contador (por exemplo, enviar uma requisição para o servidor)
  console.log('Valor do contador atualizado:', value);
}

// Função de clique do botão
function handleClick() {
  var button = document.getElementById('likeButton');
  var counter = parseInt(document.getElementById('fav').textContent);

  if (button.classList.contains('liked')) {
    // Remove o número
    counter -= 1;
    button.classList.remove('liked');
  } else {
    // Adiciona o número
    counter += 1;
    button.classList.add('liked');
  }

  // Atualiza o valor do contador
  document.getElementById('fav').textContent = counter;
  updateCounter(counter);
  updateCounterLocalStorage(counter);
}

// Carrega o valor inicial do contador ao carregar a página
document.addEventListener('DOMContentLoaded', function() {
  loadCounter();
});

// Adiciona o evento de clique ao botão
document.getElementById('likeButton').addEventListener('click', handleClick);
