// Função para enviar o formulário
function submitForm(event) {
    event.preventDefault(); // Impede o envio padrão do formulário
  
    // Obtém os valores dos campos de entrada
    var username = document.getElementById('username-input').value;
    var email = document.getElementById('email-input').value;
    var password = document.getElementById('password-input').value;
    var confirmPassword = document.getElementById('confirm-password-input').value;
  
    // Verifica se algum campo está vazio
    if (username === '' || email === '' || password === '' || confirmPassword === '') {
      alert("Por favor, preencha todos os campos.");
      return;
    }
  
    // Verifica se a senha coincide com a confirmação da senha
    if (password !== confirmPassword) {
      alert("As senhas não coincidem. Por favor, tente novamente.");
      return;
    }
  
    // Cria um objeto para representar o novo usuário
    var user = {
      "username": username,
      "email": email,
      "password": password
    };
  
    // Obtém os dados existentes do localStorage
    var storedData = localStorage.getItem('userData');
    var data;
  
    if (storedData) {
      data = JSON.parse(storedData);
      data.users.push(user);
    } else {
      data = {
        "users": [user]
      };
    }
  
    // Salva os dados atualizados no localStorage
    saveDataLocally(data);
  
    // Limpa os campos de entrada
    clearFields();
  
    // Exibe uma mensagem de sucesso
    alert("Registro realizado com sucesso!");
  }
  
  // Função para salvar os dados localmente
  function saveDataLocally(data) {
    localStorage.setItem('userData', JSON.stringify(data));
  }
  
  // Função para limpar os campos de entrada
  function clearFields() {
    document.getElementById('username-input').value = '';
    document.getElementById('email-input').value = '';
    document.getElementById('password-input').value = '';
    document.getElementById('confirm-password-input').value = '';
  }
  
  // Vincula o evento de envio do formulário à função submitForm
  document.getElementById('signup-form').addEventListener('submit', submitForm);
  

  
  
  